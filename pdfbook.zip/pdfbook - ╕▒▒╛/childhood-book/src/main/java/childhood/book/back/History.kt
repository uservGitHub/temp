package childhood.book.back

/**
 * Created by Administrator on 2018/1/2.
 */

data class History(val names:List<String>,val vX:Int,val vY:Int)